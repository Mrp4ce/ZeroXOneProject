<?php 
require "function/function.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome to Index</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="text-logo">
                <h2>PACE TRAVEL</h2>
            </div>
        </div>
        <nav>
            <ul>
                <li><a href="">HOME</a></li>
                <li><a href="">TRAVEL</a></li>
                <li><a href="">PROMO</a></li>
                <li><a href="">PROFIL</a></li>
                <li><a href="">KONTAK</a></li>
            </ul>
        </nav>
    </header>

    <div class="konten">
        <div class="utama">

        <!-- THIS PART TO CONNECT AND DISPLAY WITH YOUR DATABASE,MAKE SURE YOU ALREADY DATABASE TO USING IT -->

                <?php $ambil=mysqli_query($conn,"SELECT * FROM destinasi");?>
              <?php while($pecah=$ambil->fetch_assoc()):?><!--  LOOPING THE TABLE WITH WHILE -->
           <div class="isi">
                <center><img src="image/destinasi/<?= $pecah["nama_destinasi"]?>.jpg" width="280px" heigh="280px"></center>
                <table>
                    <tr>
                        <td data-header="Nama Destinasi"><?php echo $pecah["nama_destinasi"] ?></td>
                        <td data-header="Nama Destinasi"><?= $pecah["kota_destinasi"]; ?></td>
                        <td data-header="Nama Destinasi"><?= $pecah["provinsi_destinasi"]; ?></td>
                        <td data-header="Nama Destinasi"><?= $pecah["harga"]; ?></td>
                        <td class="td1"><b>Deskripsi Destinasi</b> <br><br><br><?= $pecah["deskripsi_destinasi"]; ?></td>
                    </tr>
                </table>
            </div>
            <?php endwhile; ?>
        </div>
        <div class="sidebar">
            <h2>MASUK</h2>
            <img src="image/logo/log.png" width="80px" height="80px">
            <div class="formulir">
                <form action="" method="post">
                    <input type="text" name="username" placeholder="Nama">
                    <input type="password" name="password" placeholder="Kata Sandi">
                    <button type="submit" name="masuk">Masuk</button>
                    <p>Tidak Punya Akun? <a href="#">Daftar</a> </p>
                </form>
            </div>
            <p class="ketentuan">Bergabunglah Bersama Kami, Nikmati
                Perjalanan Anda dengan <b>PACETRAVEL</b>. <!--  make this like disclaimer -->
            </p>
        </div>
    </div>



    <!-- ////////////////////////////////////////// -->
    <footer>
        <p>&copy; Pace 2019 allright reserved</p>
    </footer>
<!-- //////////////////////////////////////////

sorry for not being responsive, i am not professional web designer.
maybe someone who has try my code,in the display not 
responsive. i suggest you to using google chrome or mozila firefox on pc.
or you can edit some fiture to make it responsive.if you can make it
better, i would feel very happy. :D




Thanks All.

#MRP4CE
//////////////////////////////////////// -->
</body>
</html>