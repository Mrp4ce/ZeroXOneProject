-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 08, 2019 at 03:10 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tiket`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `jenis_kelamin` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `email`, `password`, `jenis_kelamin`) VALUES
(1, 'admin', 'admin', 'admin', 'L'),
(2, 'admin', 'admin', 'admin', 'L');

-- --------------------------------------------------------

--
-- Table structure for table `destinasi`
--

CREATE TABLE `destinasi` (
  `id_destinasi` int(11) NOT NULL,
  `nama_destinasi` varchar(255) NOT NULL,
  `provinsi_destinasi` varchar(255) NOT NULL,
  `kota_destinasi` text NOT NULL,
  `deskripsi_destinasi` text NOT NULL,
  `harga` bigint(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `destinasi`
--

INSERT INTO `destinasi` (`id_destinasi`, `nama_destinasi`, `provinsi_destinasi`, `kota_destinasi`, `deskripsi_destinasi`, `harga`) VALUES
(1, 'GUNUNG SEMERU', 'JAWA TIMUR', 'PROBOLINGGO', 'Gunung Semeru atau Gunung Meru adalah sebuah gunung berapi kerucut di Jawa Timur, Indonesia. Gunung Semeru merupakan gunung tertinggi di Pulau Jawa, dengan puncaknya Mahameru, 3.676 meter dari permukaan laut (mdpl). Gunung Semeru juga merupakan gunung berapi tertinggi ketiga di Indonesia setelah Gunung Kerinci di Sumatra dan Gunung Rinjani di Nusa Tenggara Barat[1]. Kawah di puncak Gunung Semeru dikenal dengan nama Jonggring Saloko. Gunung Semeru secara administratif termasuk dalam wilayah dua kabupaten, yakni Kabupaten Malang dan Kabupaten Lumajang, Provinsi Jawa Timur. Gunung ini termasuk dalam kawasan Taman Nasional Bromo Tengger Semeru. ', 200000),
(2, 'MUSEUM PURBA SANGIRAN', 'JAWA TENGAH', 'SRAGEN', 'Museum Sangiran adalah tempat untuk menemui kerangka fosil dari manusia purba dan juga hewan purba.Tempat ini biasanya sering dikunjungi saat liburan tiba baik dari siswa hingga khalayak umum', 30000),
(3, 'KAMPUNG BATIK LAWEAN SOLO', 'JAWA TENGAH', 'SOLO', 'Kampung Batik Lawean yang berada diSolo terkenal sebagai kampung penghasil batik terbaik di jawa tengah', 15000),
(4, 'LAWANG SEWU', 'JAWA TENGAH', 'SEMARANG', 'Lawang Sewu adalah tempat bersejarah yang ada di Jawa Tengah tepatnya di Kota Lumpia Semarang, selain karna sejarahnya tentang bangsa Belanda yang membuat Lawang Sewu tetapi juga karena keindahan yang ada diKota Semarang', 10000),
(5, 'PULAU KARIMUN JAWA', 'JAWA TENGAH', 'JEPARA', 'Pulau Karimun Jawa adalah salah satu tempat pantai indah yang ada di Jawa Tengah, Pantai putih dihiasi dengan warna karang yang indah banyak memikat pengunjung yang berasal dari luar jawa maupun masyarakat jawa itu sendiri.', 35000),
(6, 'GREEN CANYON PANGANDARAN', 'JAWA BARAT', 'PANGANDARAN', 'Green Canyon Pangandaran adalah tempat bagi para pecinta alam yang sangat indah untuk dikunjungi. Tempat ini berada di Kota Pangandaran Jawa Barat', 55000),
(7, 'KAWAH PUTIH BANDUNG', 'JAWA BARAT', 'BANDUNG', 'Kawah Putih adalah dahulu yang sebuah kawah dari letusan gunung yang kini telah dirubah  menjadi salah satu objek wisata yang ada di Jawa Barat', 40000),
(8, 'GUNUNG RINJANI', 'NUSA TENGGARA BARAT', 'LOMBOK', 'Bagi Pecinta Alam, Gunung Rinjani  tidak lagi terdengar asing. Karena Gunung yang berada di Pulau Lombok Nusa Tenggara Barat adalah Gunung yang paling banyak untuk didaki', 300000),
(9, 'RAJA AMPAT', 'PAPUA BARAT', 'PAPUA', 'RAJA AMPAT adalah salah satu tempat wisata paling mendunia selain pantai kuta Bali.', 500000);

-- --------------------------------------------------------

--
-- Table structure for table `kereta`
--

CREATE TABLE `kereta` (
  `id_kereta` int(11) NOT NULL,
  `nama_kereta` varchar(255) NOT NULL,
  `jurusan_kereta` varchar(100) NOT NULL,
  `nomor_gerbang` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `stasiun` varchar(100) NOT NULL,
  `harga` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kereta`
--

INSERT INTO `kereta` (`id_kereta`, `nama_kereta`, `jurusan_kereta`, `nomor_gerbang`, `tanggal`, `stasiun`, `harga`) VALUES
(1, 'SUMBER JAYA 1', 'CEPU', 23, '2019-08-31', 'TAWANG', 200000),
(2, 'BLORA JAYA', 'SEMARANG-PONCOL', 21, '2019-08-28', 'NGROMBO', 20000),
(3, 'SUMBER AGUNG', 'PEMALANG', 12, '2019-09-27', 'SEMARANG-PONCOL', 90000),
(4, 'JAYA BLORA', 'CEPU', 28, '2019-01-30', 'NGROMBO', 86000),
(5, 'CEPU ABADI', 'BLORA', 11, '2019-09-29', 'SEMARANG-TAWANG', 135000),
(6, 'TRANS MAKMUR', 'JAKARTA', 26, '2019-09-22', 'MANGGARAI', 179000),
(7, 'BISNIS JAYA EXPRESS', 'BANDUNG', 13, '2019-10-10', 'PASAR SENEN', 238000),
(8, 'Tawang Jaya Ekonomi', 'SMC-PSE', 13, '2019-08-30', 'Semarang-Poncol', 120000),
(9, 'Kaligung Ekonomi', 'SMC-BB', 22, '2019-08-30', 'Semarang-Poncol', 50000),
(10, 'Kamandaka Ekonomi', 'SMT-PWT', 113, '2019-08-29', 'Semarang-Poncol', 70000),
(11, 'Argo Sindoro Eksekutif', 'SMT-GMR', 121, '2019-08-28', 'Semarang-Poncol', 255000),
(12, 'Maharani Ekonomi', 'SMC-SBI', 11, '2019-08-29', 'Semarang-Poncol', 49000),
(13, 'Kaligung Mas', 'Semarang Poncol (SMC)', 423, '2019-09-12', 'Pemalang', 67000),
(14, 'Argo Muria Eksekutif', 'Semarang Poncol (SMC)', 125, '2019-09-01', 'Gambir', 225000),
(15, 'Bangunkarta Eksekutif', 'Semarang Poncol (SMC)', 135, '2019-08-21', 'Gambir', 335000),
(16, 'Sembrani Eksekutif', 'Semarang Poncol (SMC)', 98, '2019-09-02', 'Gambir Jakarta', 340000);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id_pembayaran` int(11) NOT NULL,
  `nama_pemesan` varchar(100) NOT NULL,
  `nomor_telephone` bigint(100) NOT NULL,
  `dewasa` int(100) NOT NULL,
  `anak_anak` int(100) NOT NULL,
  `nama_kereta` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `tujuan` varchar(110) NOT NULL,
  `harga` bigint(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id_pembayaran`, `nama_pemesan`, `nomor_telephone`, `dewasa`, `anak_anak`, `nama_kereta`, `tanggal`, `tujuan`, `harga`) VALUES
(1, 'azis', 79786696959595, 4, 1, 'CEPU ABADI', '2019-09-29', '', 675000),
(2, 'azis', 79786696959595, 4, 1, 'CEPU ABADI', '2019-09-29', 'BLORA', 675000),
(3, 'azis', 79786696959595, 4, 1, 'CEPU ABADI', '2019-09-29', 'BLORA', 675000),
(4, 'azis', 79786696959595, 4, 1, 'CEPU ABADI', '2019-09-29', 'BLORA', 675000),
(5, 'Ahmad Mahmudah Zulfikar', 88586279151, 3, 0, 'BISNIS JAYA EXPRESS', '2019-10-10', 'BANDUNG', 714000),
(6, 'fathoni', 82232003233, 1, 0, 'BISNIS JAYA EXPRESS', '2019-10-10', 'BANDUNG', 238000),
(7, 'Wahyu Ahmad Pambudi', 89, 4, 0, 'Kamandaka Ekonomi', '2019-08-29', 'SMT-PWT', 280000),
(8, 'admin12', 8986496494734725, 2, 1, 'BISNIS JAYA EXPRESS', '2019-10-10', 'BANDUNG', 714000);

-- --------------------------------------------------------

--
-- Table structure for table `payment_destinasi`
--

CREATE TABLE `payment_destinasi` (
  `id_payment_destinasi` int(11) NOT NULL,
  `nama_pemesan` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `hari` date NOT NULL,
  `waktu` time(6) NOT NULL,
  `nama_destinasi` varchar(100) NOT NULL,
  `provinsi_destinasi` varchar(100) NOT NULL,
  `kota_destinasi` varchar(110) NOT NULL,
  `harga` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_destinasi`
--

INSERT INTO `payment_destinasi` (`id_payment_destinasi`, `nama_pemesan`, `jumlah`, `hari`, `waktu`, `nama_destinasi`, `provinsi_destinasi`, `kota_destinasi`, `harga`) VALUES
(3, 'Saypul Anwar', 1, '2019-08-29', '22:23:09.000000', 'GUNUNG SEMERU', 'JAWA TIMUR', 'PROBOLINGGO', 200000),
(4, 'Saypul Anwar', 1, '2019-08-29', '22:28:30.000000', 'GUNUNG SEMERU', 'JAWA TIMUR', 'PROBOLINGGO', 200000);

-- --------------------------------------------------------

--
-- Table structure for table `sesi_belanja`
--

CREATE TABLE `sesi_belanja` (
  `id_belanja` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `telephone` bigint(100) NOT NULL,
  `dewasa` int(100) NOT NULL,
  `anak_anak` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `id_kereta` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sesi_belanja`
--

INSERT INTO `sesi_belanja` (`id_belanja`, `nama`, `telephone`, `dewasa`, `anak_anak`, `tanggal`, `id_kereta`) VALUES
(8, 'sflfhslfhl', 80420720, 1, 1, '2019-08-27', 1),
(9, 'Arya', 80420720, 1, 1, '2019-08-27', 1),
(10, 'Arya Adhi', 979573979, 1, 0, '2019-08-27', 4),
(11, 'arya', 979573979, 2, 0, '2019-08-27', 4),
(12, 'adhi', 979573979, 3, 0, '2019-08-27', 2),
(13, 'AHMAD', 979573979, 2, 0, '2019-08-27', 5),
(14, 'arya', 89979699, 1, 0, '2019-08-27', 7),
(15, 'arya', 970060, 2, 0, '2019-08-27', 5),
(16, 'arya', 8807070, 3, 0, '2019-08-27', 6),
(17, 'ahymadd nurul', 796969, 3, 0, '2019-08-27', 6),
(18, 'ahmad', 796969, 3, 0, '2019-08-27', 6),
(19, 'ahmad', 87796969796, 5, 0, '2019-08-27', 1),
(20, 'AhMad', 9007060606, 2, 0, '2019-08-28', 2),
(21, 'ahmad', 897685848, 3, 0, '2019-08-27', 4),
(22, 'Ari S', 890970606, 2, 0, '2019-08-12', 5),
(23, 'wahyu', 99768755585, 1, 0, '2019-08-28', 6),
(24, 'azis', 79786696959595, 4, 1, '2019-08-28', 5),
(25, 'Ahmad Mahmudah Zulfikar', 88586279151, 3, 0, '2019-08-31', 7),
(26, 'fathoni', 82232003233, 1, 0, '2019-08-30', 7),
(27, 'andre', 896675432751, 1, 0, '2019-08-29', 13),
(28, 'Mustofa ali baharuddin', 89775824137, 1, 0, '2019-08-30', 12),
(29, 'Wahyu Ahmad Pambudi', 89, 4, 0, '2019-08-31', 10),
(30, 'admin12', 8986496494734725, 2, 1, '2019-08-31', 7);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(16) NOT NULL,
  `alamat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `email`, `password`, `alamat`) VALUES
(1, 'pace', 'root', 'root', 'alamat'),
(7, 'admin', 'root', 'root', 'root'),
(8, 'wahyu12', 'wahyu12@hotmail.com', '1', 'pasundan banten');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `destinasi`
--
ALTER TABLE `destinasi`
  ADD PRIMARY KEY (`id_destinasi`);

--
-- Indexes for table `kereta`
--
ALTER TABLE `kereta`
  ADD PRIMARY KEY (`id_kereta`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id_pembayaran`);

--
-- Indexes for table `payment_destinasi`
--
ALTER TABLE `payment_destinasi`
  ADD PRIMARY KEY (`id_payment_destinasi`);

--
-- Indexes for table `sesi_belanja`
--
ALTER TABLE `sesi_belanja`
  ADD PRIMARY KEY (`id_belanja`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `destinasi`
--
ALTER TABLE `destinasi`
  MODIFY `id_destinasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `kereta`
--
ALTER TABLE `kereta`
  MODIFY `id_kereta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `payment_destinasi`
--
ALTER TABLE `payment_destinasi`
  MODIFY `id_payment_destinasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sesi_belanja`
--
ALTER TABLE `sesi_belanja`
  MODIFY `id_belanja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
