<?php 
$localhost= "localhost";
$user="root";
$pass="";
$db="tiket";
$conn=mysqli_connect($localhost,$user,$pass,$db);
if($conn){
    echo "";
}else{
    echo "disconnect";
}


?>