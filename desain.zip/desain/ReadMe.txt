<!-- //////////////////////////////////////////

sorry for not being responsive, i am not professional web designer.
maybe someone who has try my code,in the display not 
responsive. i suggest you to using google chrome or mozila firefox on pc.
or you can edit some fiture to make it responsive.if you can make it
better, i would feel very happy. :D




//////////////////////////////////////// -->

to using this project, you must import kereta.sql into your phpmyadmin.
don't forget to running it with web server apps and copy into your folder htdocs.!

//////////////////////////////////////////////
Thanks All.

#MRP4CE